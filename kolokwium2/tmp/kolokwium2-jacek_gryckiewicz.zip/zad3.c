#include <stdio.h>



int main(int argc, char* argv[]){
    
    int input;
    scanf("%d", &input);

    int number_of_spaces = input - 1;
    int 

    int count = input;
    for (int i = 0; i < count; i++)
    {
        
    }
    

    return 0;
}